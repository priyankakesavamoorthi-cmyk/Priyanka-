// No JavaScript code is required for this basic portfolio layout.

// However, if you want to add smooth scrolling to the sections,

// you can use the following code:

document.querySelectorAll('a[href^="#"]').forEach(anchor => {

  anchor.addEventListener('click', function (e) {

    e.preventDefault();

    document.querySelector(this.getAttribute('href')).scrollIntoView({

      behavior: 'smooth'

    });

  });

});